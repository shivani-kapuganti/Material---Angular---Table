import {Component, ViewChild} from '@angular/core';
import {APIServiceService } from './api-service.service';
import {MatPaginator, MatSort, MatTableDataSource} from '@angular/material';

export interface Data {
  userId: string;
  Id: string;
  title: string;
  completed: string;
}

const ELEMENT_DATA: Data[] = [
];


@Component({
  selector: 'table-basic-example',
  styleUrls: ['table-basic-example.css'],
  templateUrl: 'table-basic-example.html',
})
export class TableBasicExample {
  displayedColumns: string[] = ['userId', 'title', 'completed'];
   dataSource: MatTableDataSource<Data>;

   @ViewChild(MatSort, {static: false}) sort: MatSort;
   @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;



  constructor(private service : APIServiceService){
    
    this.service.getData().then(data => {
      this.dataSource = data;
    });
  }

   ngAfterViewInit() {
     setTimeout(() => this.dataSource.sort = this.sort);
     setTimeout(() => this.dataSource.paginator = this.paginator);
  }
 

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); 
    filterValue = filterValue.toLowerCase(); 
    this.dataSource.filter = filterValue;
  }
 


}
