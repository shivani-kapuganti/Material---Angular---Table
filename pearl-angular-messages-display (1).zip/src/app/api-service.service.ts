import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders }    from '@angular/common/http';

@Injectable()
export class APIServiceService {

  constructor(private http: HttpClient) { }

  getData() : Promise<any>{
    return this.http.get('https://x17hs8niwh.execute-api.us-east-1.amazonaws.com/dev/demo/get-seekers').
    toPromise();
  }

}